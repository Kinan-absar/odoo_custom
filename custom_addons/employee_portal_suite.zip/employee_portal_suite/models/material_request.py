from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import timedelta
from odoo.exceptions import ValidationError
from odoo.tools import html2plaintext
import re
import base64

class MaterialRequest(models.Model):
    _name = 'material.request'
    _description = 'Material Request'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'id desc'

    # ---------------------------------------------------------
    # BASIC FIELDS
    # ---------------------------------------------------------
    name = fields.Char(
        string='MR Number',
        readonly=True,
        copy=False,
        default=lambda self: _('New'),
        tracking=True
    )

    employee_id = fields.Many2one(
        'hr.employee',
        string='Employee',
        required=True,
        tracking=True
    )

    manager_id = fields.Many2one(
        'hr.employee',
        string='Direct Manager',
        compute="_compute_manager",
        store=True
    )

    request_date = fields.Date(
        string='Request Date',
        default=fields.Date.context_today,
        tracking=True
    )

    worksite = fields.Char(string="Worksite", required=True)
    delivery_date = fields.Date(string="Delivery Date")

    line_ids = fields.One2many(
        'material.request.line',
        'request_id',
        string="Materials"
    )
    work_location_id = fields.Many2one(
            "hr.work.location",
            string="Work Location",
            readonly=True,
            tracking=True
    )

    project_id = fields.Many2one(
        "project.project",
        string="Project",
        compute="_compute_project_from_employee",
        store=True,
        tracking=True
    )
    store_manager_user_id = fields.Many2one(
        "res.users",
        string="Store Manager (Project)",
        compute="_compute_project_approvers",
        store=True,
        readonly=True
    )

    project_manager_user_id = fields.Many2one(
        "res.users",
        string="Project Manager (Project)",
        compute="_compute_project_approvers",
        store=True,
        readonly=True
    )
    last_log_note = fields.Text(
        string="Last Log Note",
        compute="_compute_last_log_note",
        store=True,
    )
    expense_account_id = fields.Many2one(
        "account.account",
        string="Expense Account",
        domain="[('account_type', 'in', ('expense','expense_direct_cost'))]",
        tracking=True,
    )

    # ---------------------------------------------------------
    # PURCHASE / ACCOUNTING DOCUMENT TRACKING
    # ---------------------------------------------------------
    no_po_required = fields.Boolean(
        string="No PO Required",
        tracking=True,
        help="Check this when this approved MR does not require a Purchase Order, for example small purchases below the company threshold."
    )
    po_created = fields.Boolean(
        string="PO Created",
        compute="_compute_po_created",
        store=False,
    )
    accounting_docs_status = fields.Selection([
        ("pending", "Pending Invoice"),
        ("submitted", "Submitted to Accounting"),
        ("received", "Received by Accounting"),
        ("need_more", "Need More Invoice Docs"),
        ("processed", "Processed"),
        ("rejected", "Rejected"),
    ], string="Invoice Submission Status", default="pending", tracking=True)
    quotation_status_override = fields.Selection([
        ("uploaded", "Quotations Uploaded"),
        ("exception_approved", "Exception Approved"),
        ("single_source_approved", "Single Source Approved"),
    ], string="Quotation Status Override", tracking=True,
       help="Optional manual override when fewer than three quotations are acceptable or an exception is approved.")
    quotation_attachment_count = fields.Integer(
        string="Quotation Count",
        compute="_compute_quotation_status",
        store=False,
    )
    quotation_status = fields.Selection([
        ("pending", "Pending Quotations"),
        ("remaining_2", "Remaining 2 Quotations"),
        ("remaining_1", "Remaining 1 Quotation"),
        ("uploaded", "Quotations Uploaded"),
        ("exception_approved", "Exception Approved"),
        ("single_source_approved", "Single Source Approved"),
    ], string="Quotation Status", compute="_compute_quotation_status", store=False)
    docs_submitted_by = fields.Many2one(
        "res.users",
        string="Docs Submitted By",
        readonly=True,
        tracking=True,
    )
    docs_submitted_date = fields.Datetime(
        string="Docs Submitted Date",
        readonly=True,
        tracking=True,
    )
    accounting_docs_note = fields.Text(
        string="Note to Accounting",
        tracking=True,
    )
    accounting_docs_submitted_attachment_count = fields.Integer(
        string="Submitted Accounting Attachment Count",
        readonly=True,
        default=0,
        copy=False,
        help="Technical field used by the portal to show Submit to Accounting only when new accounting documents were uploaded after the last submission.",
    )

    @api.depends("purchase_order_ids")
    def _compute_po_created(self):
        for rec in self:
            rec.po_created = bool(rec.purchase_order_ids)

    def _attachment_domain_by_category(self, category):
        self.ensure_one()
        legacy_description = {
            "invoice_submission": "Accounting Documents",
            "quotation": "Quotation Documents",
            "general": "General",
        }.get(category, "General")
        return [
            ("res_model", "=", "material.request"),
            ("res_id", "=", self.id),
            ("description", "=", legacy_description),
        ]

    def _get_mr_attachment_count_by_category(self, category):
        self.ensure_one()
        return self.env["ir.attachment"].sudo().search_count(
            self._attachment_domain_by_category(category)
        )

    def _compute_quotation_status(self):
        for rec in self:
            count = rec._get_mr_attachment_count_by_category("quotation") if rec.id else 0
            rec.quotation_attachment_count = count
            if rec.quotation_status_override:
                rec.quotation_status = rec.quotation_status_override
            elif count <= 0:
                rec.quotation_status = "pending"
            elif count == 1:
                rec.quotation_status = "remaining_2"
            elif count == 2:
                rec.quotation_status = "remaining_1"
            else:
                rec.quotation_status = "uploaded"

    def _get_accounting_attachment_count(self):
        self.ensure_one()
        return self._get_mr_attachment_count_by_category("invoice_submission")

    def has_unsubmitted_accounting_docs(self):
        self.ensure_one()
        return self._get_accounting_attachment_count() > self.accounting_docs_submitted_attachment_count

    def action_submit_docs_to_accounting(self, note=False):
        for rec in self:
            attachment_count = rec._get_accounting_attachment_count()
            if not attachment_count or attachment_count <= rec.accounting_docs_submitted_attachment_count:
                continue

            if note is not False:
                rec.accounting_docs_note = note
            rec.accounting_docs_status = "submitted"
            rec.docs_submitted_by = self.env.user.id
            rec.docs_submitted_date = fields.Datetime.now()
            rec.accounting_docs_submitted_attachment_count = attachment_count

            body = _("Invoice documents submitted to Accounting.")
            if rec.accounting_docs_note:
                body += "\n\n%s\n%s" % (_("Note to Accounting:"), rec.accounting_docs_note)
            rec.message_post(body=body, message_type="comment", subtype_xmlid="mail.mt_comment")

    vendor_bill_ids = fields.One2many(
        "account.move",
        "material_request_id",
        string="Vendor Bills",
        domain=[("move_type", "=", "in_invoice")],
    )
    vendor_bill_count = fields.Integer(
        string="Created Vendor Bills",
        compute="_compute_vendor_bill_count",
    )
    can_create_vendor_bill = fields.Boolean(
        string="Can Create Vendor Bill",
        compute="_compute_can_create_vendor_bill",
        store=False,
    )

    def _compute_vendor_bill_count(self):
        for rec in self:
            rec.vendor_bill_count = len(rec.vendor_bill_ids)

    @api.depends("state", "no_po_required", "vendor_bill_ids", "purchase_order_ids")
    def _compute_can_create_vendor_bill(self):
        for rec in self:
            # Direct vendor bills are only for No-PO MRs. If a PO exists,
            # the vendor bill should be created from the PO/vendor bill flow.
            rec.can_create_vendor_bill = (
                rec.state == "approved"
                and rec.no_po_required
                and not rec.purchase_order_ids
            )

    def _prepare_vendor_bill_line_vals(self):
        self.ensure_one()
        lines = []
        for line in self.line_ids:
            vals = {
                "name": line.item_name or self.name,
                "quantity": line.qty_required or 1.0,
            }
            if self.expense_account_id:
                vals["account_id"] = self.expense_account_id.id
            if line.uom_id:
                vals["product_uom_id"] = line.uom_id.id
            lines.append((0, 0, vals))
        return lines

    def action_create_vendor_bill(self):
        self.ensure_one()

        if not self.no_po_required:
            raise UserError(_("Vendor Bill can only be created directly when No PO Required is checked."))

        return {
            "type": "ir.actions.act_window",
            "name": _("Vendor Bill"),
            "res_model": "account.move",
            "view_mode": "form",
            "target": "current",
            "context": {
                "default_move_type": "in_invoice",
                "default_material_request_id": self.id,
                "default_invoice_line_ids": self._prepare_vendor_bill_line_vals(),
            },
        }

    def action_open_vendor_bills(self):
        self.ensure_one()

        bills = self.vendor_bill_ids.filtered(lambda move: move.move_type == "in_invoice")
        if not bills:
            return {
                "type": "ir.actions.act_window",
                "name": _("Vendor Bill"),
                "res_model": "account.move",
                "view_mode": "form",
                "target": "current",
                "context": {
                    "default_move_type": "in_invoice",
                    "default_material_request_id": self.id,
                        "default_invoice_line_ids": self._prepare_vendor_bill_line_vals(),
                },
            }

        action = {
            "type": "ir.actions.act_window",
            "name": _("Vendor Bills"),
            "res_model": "account.move",
            "view_mode": "list,form",
            "domain": [("id", "in", bills.ids)],
            "context": {"default_move_type": "in_invoice"},
            "target": "current",
        }
        if len(bills) == 1:
            action.update({"view_mode": "form", "res_id": bills.id})
        return action

    # ---------------------------------------------------------
    # CLARIFICATION
    # ---------------------------------------------------------
    needs_clarification = fields.Boolean(default=False)

    clarification_stage = fields.Selection(
        selection=lambda self: self._fields['state'].selection,
        string="Clarification Stage"
    )

    can_toggle_clarification = fields.Boolean(
        compute="_compute_can_toggle_clarification"
    )

    def _compute_can_toggle_clarification(self):
        for rec in self:
            rec.can_toggle_clarification = rec._can_toggle_clarification()


    def _can_toggle_clarification(self):
        self.ensure_one()
        user = self.env.user

        # Cannot toggle in these states
        if self.state in ("draft", "approved", "rejected"):
            return False

        # Project based stages
        if self.state == "store":
            return user == self.store_manager_user_id

        if self.state == "project_manager":
            return user == self.project_manager_user_id

        # Group based stages
        stage_group_map = {
            "purchase": "employee_portal_suite.group_mr_purchase_rep",
            "director": "employee_portal_suite.group_mr_projects_director",
            "ceo": "employee_portal_suite.group_employee_portal_ceo",
        }

        group = stage_group_map.get(self.state)
        if group:
            return user.has_group(group)

        return False

    def write(self, vals):

        if "needs_clarification" in vals:
            for rec in self:

                if not rec._can_toggle_clarification():
                    raise UserError(_("You are not allowed to toggle clarification at this stage."))

                # When turning ON → remember stage
                if vals.get("needs_clarification"):
                    vals["clarification_stage"] = rec.state

                # When turning OFF → clear stage
                else:
                    vals["clarification_stage"] = False

        return super().write(vals)

    display_state = fields.Char(
        string="Display Status",
        compute="_compute_display_state",
        store=False
    )

    @api.depends("state", "needs_clarification", "clarification_stage")
    def _compute_display_state(self):
        stage_labels = dict(self._fields['state'].selection)

        for rec in self:
            if rec.needs_clarification and rec.clarification_stage:
                stage_name = stage_labels.get(rec.clarification_stage, "")
                rec.display_state = f"🚩 Clarification — {stage_name}"
            else:
                rec.display_state = stage_labels.get(rec.state, "")



    # ---------------------------------------------------------
    # STATE MACHINE
    # ---------------------------------------------------------
    state = fields.Selection([
        ('draft', 'Draft'),
        ('purchase', 'Purchase Representative'),
        ('store', 'Store Manager'),
        ('project_manager', 'Project Manager'),
        ('director', 'Projects Director'),
        ('ceo', 'CEO Approval'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ], default='draft', tracking=True)

    # Tracking who approved each stage
    purchase_approved_by = fields.Many2one("res.users", string="Purchase Approved By")
    store_approved_by = fields.Many2one("res.users", string="Store Manager Approved By")
    project_manager_approved_by = fields.Many2one("res.users", string="PM Approved By")
    director_approved_by = fields.Many2one("res.users", string="Director Approved By")
    ceo_approved_by = fields.Many2one("res.users", string="CEO Approved By")

    # ---------------------------------------------------------
    # APPROVAL METADATA (same pattern as employee.request)
    # ---------------------------------------------------------
    purchase_approved_by = fields.Many2one('res.users')
    purchase_approved_date = fields.Datetime()
    purchase_comment = fields.Text()

    store_approved_by = fields.Many2one('res.users')
    store_approved_date = fields.Datetime()
    store_comment = fields.Text()

    project_manager_approved_by = fields.Many2one('res.users')
    project_manager_approved_date = fields.Datetime()
    project_manager_comment = fields.Text()

    director_approved_by = fields.Many2one('res.users')
    director_approved_date = fields.Datetime()
    director_comment = fields.Text()

    ceo_approved_by = fields.Many2one('res.users')
    ceo_approved_date = fields.Datetime()
    ceo_comment = fields.Text()

    # Rejection info
    state_before_reject = fields.Char()
    rejected_by = fields.Many2one('res.users')
    #new
    @api.depends("employee_id")
    def _compute_project_from_employee(self):
        for rec in self:
            employee = rec.employee_id
            if employee and employee.work_location_id:
                rec.work_location_id = employee.work_location_id
                rec.project_id = employee.work_location_id.project_id
            else:
                rec.work_location_id = False
                rec.project_id = False
           
    @api.depends("project_id")
    def _compute_project_approvers(self):
        for rec in self:
            project = rec.project_id
            rec.store_manager_user_id = project.store_manager_user_id if project else False
            rec.project_manager_user_id = project.project_manager_user_id if project else False
            
    @api.depends("message_ids")
    def _compute_last_log_note(self):
        Message = self.env["mail.message"]
        for rec in self:
            msg = Message.search([
                ("model", "=", "material.request"),
                ("res_id", "=", rec.id),
                ("message_type", "=", "comment"),
            ], order="date desc", limit=1)

            if not msg:
                rec.last_log_note = False
                continue

            text = html2plaintext(msg.body or "")

            # -------------------------------------------------
            # REMOVE FOOTNOTE REFERENCES LIKE [1], [2], etc.
            # -------------------------------------------------
            text = re.sub(r"\[\d+\]", "", text)

            # -------------------------------------------------
            # REMOVE TRAILING URL LINES
            # -------------------------------------------------
            lines = [
                line for line in text.splitlines()
                if not line.strip().startswith("/")
            ]

            clean_text = " ".join(lines).strip()

            MAX_LEN = 50
            if len(clean_text) > MAX_LEN:
                clean_text = clean_text[:MAX_LEN].rstrip() + "…"

            rec.last_log_note = clean_text        
    # ---------------------------------------------------------
    # COMPUTE MANAGER
    # ---------------------------------------------------------
    @api.depends("employee_id")
    def _compute_manager(self):
        for rec in self:
            rec.manager_id = rec.employee_id.parent_id
    # ---------------------------------------------------------
    # DATE VALIDATION (Delivery Date must be 3+ days after Request Date)
    # ---------------------------------------------------------
    @api.onchange('request_date', 'delivery_date')
    def _onchange_delivery_date(self):
        if self.request_date and self.delivery_date:
            min_allowed = self.request_date + timedelta(days=3)
            if self.delivery_date < min_allowed:
                warning = {
                    'title': "Invalid Delivery Date",
                    'message': "Delivery Date must be at least 3 days after the Request Date."
                }
                # Reset delivery date so portal doesn't crash
                self.delivery_date = False
                return {'warning': warning}

    #employee autofilled
    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        if 'employee_id' in fields_list:
            employee = self.env.user.employee_id
            if not employee:
                raise UserError(_("Your user is not linked to an employee."))
            res['employee_id'] = employee.id
        return res
    # ---------------------------------------------------------
    # CREATE SEQUENCE
    # ---------------------------------------------------------
    @api.model
    def create(self, vals):
        if vals.get("name", _("New")) == _("New"):
            vals["name"] = self.env["ir.sequence"].next_by_code("material.request.seq") or _("New")
        return super().create(vals)

    # ---------------------------------------------------------
    # GENERIC STATE ADVANCE
    # ---------------------------------------------------------
    def _advance_state(self, new_state, group_xmlid, approved_user_field, approved_date_field):
        for rec in self:
            # Save approval info
            rec[approved_user_field] = self.env.user.id
            rec[approved_date_field] = fields.Datetime.now()
            rec.state = new_state

            rec.activity_ids.action_done()

            # -------------------------------------------------
            # PROJECT-SCOPED NOTIFICATIONS
            # -------------------------------------------------

            # Store Manager stage
            if new_state == "store" and rec.store_manager_user_id:
                user = rec.store_manager_user_id
                rec._notify_user(
                    user,
                    f"Material Request {rec.name} requires your approval",
                    f"Material Request {rec.name} is waiting for your action."
                )
                rec._schedule_activity(
                    user,
                    "Approval Needed",
                    f"Please review Material Request {rec.name}."
                )
                return

            # Project Manager stage
            if new_state == "project_manager" and rec.project_manager_user_id:
                user = rec.project_manager_user_id
                rec._notify_user(
                    user,
                    f"Material Request {rec.name} requires your approval",
                    f"Material Request {rec.name} is waiting for your action."
                )
                rec._schedule_activity(
                    user,
                    "Approval Needed",
                    f"Please review Material Request {rec.name}."
                )
                return

            # -------------------------------------------------
            # GLOBAL STAGES (PURCHASE / DIRECTOR / CEO)
            # -------------------------------------------------
            group = self.env.ref(group_xmlid, raise_if_not_found=False)
            if group:
                for user in group.users:
                    rec._notify_user(
                        user,
                        f"Material Request {rec.name} requires your approval",
                        f"Material Request {rec.name} is waiting for your action."
                    )
                    rec._schedule_activity(
                        user,
                        "Approval Needed",
                        f"Please review Material Request {rec.name}."
                    )
    # ---------------------------------------------------------
    # NOTIFY / ACTIVITY HELPERS
    # ---------------------------------------------------------
    def _notify_user(self, user, subject, body):
        if not user or not user.partner_id.email:
            return
        mail_values = {
            "subject": subject,
            "body_html": f"<p>{body}</p>",
            "email_to": user.partner_id.email,
            "author_id": self.env.user.partner_id.id,
        }
        self.env["mail.mail"].sudo().create(mail_values).send()

    def _schedule_activity(self, user, summary, note):
        self.activity_schedule(
            "mail.mail_activity_data_todo",
            user_id=user.id,
            summary=summary,
            note=note
        )
        #helper
    def _check_approval(self, required_state, required_group):
        self.ensure_one()

       # State check
        if self.state != required_state:
            raise UserError(_("This action is not allowed in the current state."))

        user = self.env.user

        # -------------------------------------------------
        # PROJECT-SCOPED STAGES
        # -------------------------------------------------
        if required_state == "store":
            if user != self.store_manager_user_id:
                raise UserError(_("You are not allowed to approve this request."))

        elif required_state == "project_manager":
            if user != self.project_manager_user_id:
                raise UserError(_("You are not allowed to approve this request."))

        # -------------------------------------------------
        # GLOBAL STAGES
        # -------------------------------------------------
        else:
            if not user.has_group(required_group):
                raise UserError(_("You are not allowed to approve at this stage."))

    # ---------------------------------------------------------
    # ACTIONS
    # ---------------------------------------------------------
    def action_submit(self):
        for rec in self:
            if rec.state != "draft":
                raise UserError("Only draft requests can be submitted.")
            # 🔴 REQUIRED: at least one material line
            if not rec.line_ids:
                raise UserError(_("You must add at least one material line before submitting the request."))

            rec.state = "purchase"
            rec.message_post(body="Material Request submitted.")
            rec.activity_ids.action_done()

            # Notify Purchase Representative group
            group = self.env.ref("employee_portal_suite.group_mr_purchase_rep", raise_if_not_found=False)
            if group:
                for user in group.users:
                    rec._notify_user(
                        user,
                        "New Material Request Awaiting Approval",
                        f"Material Request {rec.name} requires your review."
                    )
                    rec._schedule_activity(
                        user,
                        "Purchase Approval Needed",
                        f"Material Request {rec.name} has been submitted."
                    )

    def action_purchase(self):
        for rec in self:
            rec._check_approval(
                required_state="purchase",
                required_group="employee_portal_suite.group_mr_purchase_rep"
            )

            rec._advance_state(
                "store",
                "employee_portal_suite.group_mr_store_manager",
                "purchase_approved_by",
                "purchase_approved_date"
            )

    def action_store(self):
        for rec in self:
            rec._check_approval(
                required_state="store",
                required_group="employee_portal_suite.group_mr_store_manager"
            )

            rec._advance_state(
                "project_manager",
                "employee_portal_suite.group_mr_project_manager",
                "store_approved_by",
                "store_approved_date"
            )

    def action_project_manager(self):
        for rec in self:
            rec._check_approval(
                required_state="project_manager",
                required_group="employee_portal_suite.group_mr_project_manager"
            )

            rec._advance_state(
                "director",
                "employee_portal_suite.group_mr_projects_director",
                "project_manager_approved_by",
                "project_manager_approved_date"
            )

    def action_director(self):
        for rec in self:
            rec._check_approval(
                required_state="director",
                required_group="employee_portal_suite.group_mr_projects_director"
            )

            rec._advance_state(
                "ceo",
                "employee_portal_suite.group_employee_portal_ceo",
                "director_approved_by",
                "director_approved_date"
            )


    def action_ceo(self):
        for rec in self:
            rec._check_approval(
                required_state="ceo",
                required_group="employee_portal_suite.group_employee_portal_ceo"
            )

            rec.ceo_approved_by = self.env.user.id
            rec.ceo_approved_date = fields.Datetime.now()
            rec.state = "approved"
            rec._send_final_pdf_and_notify_all(
                report_xmlid="employee_portal_suite.material_request_pdf",
                subject=f"Material Request {rec.name} – Approved",
                body=f"Material Request {rec.name} has been fully approved. Please find the attached document."
            )


            rec.message_post(body="Material Request fully approved.")
            rec.activity_ids.action_done()

    def action_reject(self):
        for rec in self:
            stage_group_map = {
                "purchase": "employee_portal_suite.group_mr_purchase_rep",
                "store": "employee_portal_suite.group_mr_store_manager",
                "project_manager": "employee_portal_suite.group_mr_project_manager",
                "director": "employee_portal_suite.group_mr_projects_director",
                "ceo": "employee_portal_suite.group_employee_portal_ceo",
            }

            required_group = stage_group_map.get(rec.state)
            if not required_group:
                raise UserError(_("This request cannot be rejected at this stage."))

            if not self.env.user.has_group(required_group):
                raise UserError(_("You are not allowed to reject this request."))

            rec.state_before_reject = rec.state
            rec.rejected_by = self.env.user.id
            rec.state = "rejected"
            rec._send_final_pdf_and_notify_all(
                report_xmlid="employee_portal_suite.material_request_pdf",
                subject=f"Material Request {rec.name} – Rejected",
                body=f"Material Request {rec.name} has been rejected. Please find the attached document."
            )


            rec.message_post(body="Material Request rejected.")
            rec.activity_ids.action_done()

    def get_rejection_reason(self):
        self.ensure_one()
        comments = {
            "purchase": self.purchase_comment,
            "store": self.store_comment,
            "project_manager": self.project_manager_comment,
            "director": self.director_comment,
            "ceo": self.ceo_comment,
        }
        return comments.get(self.state_before_reject) or ""

    # ---------------------------------------------------------
    # PORTAL TIMELINE
    # ---------------------------------------------------------
    def get_portal_timeline(self):
        self.ensure_one()
        timeline = []

        stages = [
            ("purchase", "Purchase Representative", self.purchase_approved_by, self.purchase_approved_date, self.purchase_comment),
            ("store", "Store Manager", self.store_approved_by, self.store_approved_date, self.store_comment),
            ("project_manager", "Project Manager", self.project_manager_approved_by, self.project_manager_approved_date, self.project_manager_comment),
            ("director", "Projects Director", self.director_approved_by, self.director_approved_date, self.director_comment),
            ("ceo", "CEO Approval", self.ceo_approved_by, self.ceo_approved_date, self.ceo_comment),
        ]

        for state, label, user, date, comment in stages:
            if date:
                timeline.append({
                    "stage": label,
                    "approved_by": user.name if user else "",
                    "date": date,
                    "comment": comment or "",
                })

        if self.state == "rejected":
            stage_labels = {
                "purchase": "Purchase Stage",
                "store": "Store Stage",
                "project_manager": "Project Manager Stage",
                "director": "Director Stage",
                "ceo": "CEO Stage",
            }

            comments = {
                "purchase": self.purchase_comment,
                "store": self.store_comment,
                "project_manager": self.project_manager_comment,
                "director": self.director_comment,
                "ceo": self.ceo_comment,
            }

            stage_label = stage_labels.get(self.state_before_reject, "Unknown Stage")
            comment = comments.get(self.state_before_reject) or "No comment"

            timeline.append({
                "stage": f"{stage_label} - Rejected",
                "approved_by": self.rejected_by.name if self.rejected_by else "",
                "date": self.write_date,
                "comment": comment,
            })

        return timeline
        
    @api.model
    def retrieve_dashboard(self):
        domain = []
        data = {
            'all_count': self.search_count(domain),
            'draft_count': self.search_count([('state', '=', 'draft')]),
            'purchase_count': self.search_count([('state', '=', 'purchase')]),
            'store_count': self.search_count([('state', '=', 'store')]),
            'project_manager_count': self.search_count([('state', '=', 'project_manager')]),
            'director_count': self.search_count([('state', '=', 'director')]),
            'ceo_count': self.search_count([('state', '=', 'ceo')]),
            'approved_count': self.search_count([('state', '=', 'approved')]),
            'rejected_count': self.search_count([('state', '=', 'rejected')]),
            'clarification_count': self.search_count([('needs_clarification', '=', True)]),
            'my_count': self.search_count([('create_uid', '=', self.env.user.id)]),
            'po_required_count': self.search_count([('no_po_required', '=', False)]),
            'no_po_required_count': self.search_count([('no_po_required', '=', True)]),
        }
        return data

    def get_readable_status(self):
        mapping = {
            "purchase": "Pending Purchase",
            "store": "Pending Store Manager",
            "project_manager": "Pending PM",
            "director": "Pending Director",
            "ceo": "Pending CEO",
            "approved": "Fully Approved",
            "rejected": "Rejected",
        }
        return mapping.get(self.state, "Unknown")


    #Purchase Extension 
    def action_create_po(self):
        self.ensure_one()

        return {
            "type": "ir.actions.act_window",
            "name": "Purchase Order",
            "res_model": "purchase.order",
            "view_mode": "form",
            "target": "current",
            "context": {
                "default_material_request_id": self.id,
            },
        }

    # LINK TO PURCHASE ORDERS (required)
    purchase_order_ids = fields.One2many(
        "purchase.order",
        "material_request_id",
        string="Purchase Orders",
    )

    # SHOW PO NUMBER(S) IN LIST VIEW
    po_name = fields.Char(
        string="Purchase Order",
        compute="_compute_po_name",
        store=False,
    )
    po_status = fields.Char(
        string="PO Status",
        compute="_compute_po_status",
        store=False,
    )

    # ❗❗ INSERTED HERE — BUTTON VISIBILITY BOOLEAN ❗❗
    can_create_po = fields.Boolean(
        compute="_compute_can_create_po",
        store=False,
    )

    def _compute_can_create_po(self):
        for rec in self:
            # Allow more than one PO to be created from the same approved MR.
            # The button is hidden only when this MR is marked as No PO Required.
            rec.can_create_po = (
                rec.state == "approved"
                and not rec.no_po_required
            )

    # END OF INSERTION

    def _compute_po_name(self):
        for rec in self:
            if len(rec.purchase_order_ids) == 1:
                rec.po_name = rec.purchase_order_ids.name
            elif len(rec.purchase_order_ids) > 1:
                rec.po_name = ", ".join(rec.purchase_order_ids.mapped("name"))
            else:
                rec.po_name = ""
                #status badge
    def _compute_po_status(self):
        for rec in self:

            # Always assign something (avoid crash)
            if not rec.purchase_order_ids:
                rec.po_status = False
                continue

            po = rec.purchase_order_ids[0]  # Usually only 1 PO

            mapping = {
                "draft": "RFQ",
                "sent": "RFQ Sent",
                "to approve": "Waiting Approval",
                "purchase": "Purchase Order",
                "done": "Received",
                "cancel": "Cancelled",
            }

            rec.po_status = mapping.get(po.state, po.state)

    def action_open_po(self):
        self.ensure_one()

        if not self.purchase_order_ids:
            return

        # If exactly one PO → open directly in form view
        if len(self.purchase_order_ids) == 1:
            po = self.purchase_order_ids[0]
            return {
                "type": "ir.actions.act_window",
                "name": "Purchase Order",
                "res_model": "purchase.order",
                "res_id": po.id,
                "view_mode": "form",
                "target": "current",
            }

        # If multiple POs → open list + form views
        return {
            "type": "ir.actions.act_window",
            "name": "Purchase Orders",
            "res_model": "purchase.order",
            "domain": [("id", "in", self.purchase_order_ids.ids)],
            "view_mode": "list,form",
            "target": "current",
        }
    def _send_final_pdf_and_notify_all(self, report_xmlid, subject, body):
        self.ensure_one()

        # --------------------------------------------------
        # 1) Render PDF
        # --------------------------------------------------
        report = self.env.ref(report_xmlid)
        pdf_content, _ = self.env['ir.actions.report']._render_qweb_pdf(
            report.id, [self.id]
        )

        attachment = self.env['ir.attachment'].sudo().create({
            'name': f"{self.name}.pdf",
            'type': 'binary',
            'datas': base64.b64encode(pdf_content),
            'res_model': self._name,
            'res_id': self.id,
            'mimetype': 'application/pdf',
        })

        # --------------------------------------------------
        # 2) Collect users / emails
        # --------------------------------------------------
        partners = set()
        emails = set()

        def _add_user(user):
            if not user or not user.partner_id:
                return
            partners.add(user.partner_id.id)
            if user.partner_id.email:
                emails.add(user.partner_id.email)

        # Requester
        if self.employee_id.user_id:
            _add_user(self.employee_id.user_id)

        # Approvers
        approver_fields = [
            'manager_approved_by',
            'hr_approved_by',
            'finance_approved_by',
            'purchase_approved_by',
            'store_approved_by',
            'project_manager_approved_by',
            'director_approved_by',
            'ceo_approved_by',
        ]

        for field in approver_fields:
            if field in self._fields:
                _add_user(getattr(self, field))

        # --------------------------------------------------
        # 4) EMAIL (SMTP) with PDF
        # --------------------------------------------------
        if emails:
            mail = self.env['mail.mail'].sudo().create({
                'subject': subject,
                'body_html': f"<p>{body}</p>",
                'email_to': ",".join(emails),
                'attachment_ids': [(4, attachment.id)],
                'author_id': self.env.user.partner_id.id,
            })
            mail.send()



        
from odoo import models, api

class IrAttachment(models.Model):
    _inherit = 'ir.attachment'

    @api.model_create_multi
    def create(self, vals_list):
        records = super().create(vals_list)
        for att in records:
            if att.res_model == 'material.request':
                att.public = True
        return records
