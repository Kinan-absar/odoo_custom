from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError


class ConstructionContract(models.Model):
    _name = 'construction.contract'
    _description = 'Construction Contract'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'id desc'

    name = fields.Char(string='Contract Reference', required=True, copy=False, default='New', tracking=True)
    project_id = fields.Many2one('project.project', string='Project', tracking=True)
    partner_id = fields.Many2one('res.partner', string='Partner', required=True, tracking=True)
    company_id = fields.Many2one('res.company', string='Company', required=True, default=lambda self: self.env.company)
    currency_id = fields.Many2one(
        'res.currency',
        string='Currency',
        required=True,
        default=lambda self: self.env.company.currency_id,
        tracking=True,
    )

    contract_direction = fields.Selection([
        ('inbound', 'Client Contract'),
        ('outbound', 'Subcontract'),
    ], string='Contract Direction', required=True, default='outbound', tracking=True)

    sale_order_id = fields.Many2one(
        'sale.order',
        string='Source Sales Order',
        copy=False,
        readonly=True,
        index=True,
        ondelete='restrict',
        tracking=True,
    )
    customer_reference = fields.Char(string='Customer Reference', tracking=True)
    source_sale_amount = fields.Monetary(
        string='Sales Order Untaxed Amount',
        related='sale_order_id.amount_untaxed',
        currency_field='currency_id',
        readonly=True,
    )

    scope = fields.Text(string='Scope of Work')
    date_start = fields.Date(string='Start Date')
    date_end = fields.Date(string='End Date')

    original_amount = fields.Monetary(string='Original Amount', currency_field='currency_id', tracking=True)
    boq_original_amount = fields.Monetary(
        string='Original BOQ Amount',
        currency_field='currency_id',
        compute='_compute_boq_comparison',
        store=True,
    )
    boq_difference = fields.Monetary(
        string='BOQ Difference',
        currency_field='currency_id',
        compute='_compute_boq_comparison',
        store=True,
        help='Original Amount minus the sum of original BOQ lines.',
    )
    boq_matches_original = fields.Boolean(
        string='BOQ Matches Original Amount',
        compute='_compute_boq_comparison',
        store=True,
    )
    revised_amount = fields.Monetary(
        string='Revised Amount',
        currency_field='currency_id',
        compute='_compute_revised_amount',
        store=True,
    )
    payment_term_id = fields.Many2one(
        'account.payment.term',
        string='Payment Terms',
        tracking=True,
    )
    retention_percent = fields.Float(string='Retention %')
    advance_percent = fields.Float(string='Advance %')
    vat_percent = fields.Float(string='VAT %', default=15.0)

    advance_amount = fields.Monetary(
        string='Advance Amount',
        currency_field='currency_id',
        compute='_compute_advance_amount',
        store=True,
    )
    advance_recovered = fields.Monetary(
        string='Advance Recovered',
        currency_field='currency_id',
        default=0.0,
        tracking=True,
    )
    advance_balance = fields.Monetary(
        string='Advance Balance',
        currency_field='currency_id',
        compute='_compute_advance_balance',
        store=True,
    )
    advance_ids = fields.One2many('construction.advance', 'contract_id', string='Advances')
    advance_count = fields.Integer(compute='_compute_advance_count')

    retention_held = fields.Monetary(
        string='Retention Held',
        currency_field='currency_id',
        compute='_compute_retention_balances',
        store=True,
    )
    retention_released = fields.Monetary(
        string='Retention Released',
        currency_field='currency_id',
        compute='_compute_retention_balances',
        store=True,
    )
    retention_balance = fields.Monetary(
        string='Retention Balance',
        currency_field='currency_id',
        compute='_compute_retention_balances',
        store=True,
    )

    retention_release_ids = fields.One2many(
        'construction.retention.release',
        'contract_id',
        string='Retention Releases',
    )
    retention_release_count = fields.Integer(compute='_compute_retention_release_count')

    total_measured_amount = fields.Monetary(
        string='Total Measured Amount',
        currency_field='currency_id',
        compute='_compute_summary_amounts',
        store=True,
    )

    total_certified_amount = fields.Monetary(
        string='Total Certified Amount',
        currency_field='currency_id',
        compute='_compute_summary_amounts',
        store=True,
    )

    total_move_amount = fields.Monetary(
        string='Total Invoiced/Billed',
        currency_field='currency_id',
        compute='_compute_summary_amounts',
        store=True,
    )

    total_paid_amount = fields.Monetary(
        string='Total Paid',
        currency_field='currency_id',
        compute='_compute_summary_amounts',
        store=True,
    )

    completion_percent = fields.Float(
        string='Completion %',
        compute='_compute_summary_amounts',
        store=True,
    )
    # Accounting setup
    journal_id = fields.Many2one('account.journal', string='Accounting Journal')
    work_account_id = fields.Many2one('account.account', string='Work Account')
    advance_account_id = fields.Many2one('account.account', string='Advance Recovery Account')
    retention_account_id = fields.Many2one('account.account', string='Retention Account')
    tax_id = fields.Many2one('account.tax', string='VAT Tax')

    notes = fields.Text(string='Internal Notes')

    portal_visibility_restricted = fields.Boolean(
        string='Restrict Portal Visibility',
        help='When enabled, only the selected portal employees can see this contract and related records in the portal.',
    )
    portal_employee_ids = fields.Many2many(
        'hr.employee',
        'construction_contract_portal_employee_rel',
        'contract_id',
        'employee_id',
        string='Portal Employees',
        help='Employees allowed to see this contract and related records in the portal.',
    )
    internal_visibility_restricted = fields.Boolean(
        string='Restrict Internal Visibility',
        help='When enabled, only the selected internal employees can see this contract and related records in Odoo.',
    )
    internal_employee_ids = fields.Many2many(
        'hr.employee',
        'construction_contract_internal_employee_rel',
        'contract_id',
        'employee_id',
        string='Internal Employees',
        help='Employees allowed to see this contract and related records inside Odoo.',
    )

    boq_line_ids = fields.One2many('construction.contract.boq.line', 'contract_id', string='BOQ Lines')
    contract_order_ids = fields.One2many('construction.contract.order', 'contract_id', string='Contract Orders')
    contract_order_count = fields.Integer(compute='_compute_counts')
    measurement_ids = fields.One2many('construction.measurement', 'contract_id', string='Measurements')
    ipc_ids = fields.One2many('construction.ipc', 'contract_id', string='IPCs')

    boq_line_count = fields.Integer(compute='_compute_counts')
    measurement_count = fields.Integer(compute='_compute_counts')
    ipc_count = fields.Integer(compute='_compute_counts')
    variation_count = fields.Integer(compute='_compute_variation_count')

    state = fields.Selection([
        ('draft', 'Draft'),
        ('under_review', 'Under Review'),
        ('approved', 'Approved'),
        ('active', 'Active'),
        ('completed', 'Completed'),
        ('closed', 'Closed'),
        ('cancelled', 'Cancelled'),
    ], default='draft', tracking=True)

    @api.depends('original_amount', 'boq_line_ids.total_amount', 'currency_id')
    def _compute_boq_comparison(self):
        for rec in self:
            boq_total = sum(rec.boq_line_ids.filtered(lambda l: not l.display_type).mapped('total_amount'))
            difference = (rec.original_amount or 0.0) - boq_total
            rec.boq_original_amount = boq_total
            rec.boq_difference = difference
            rounding = rec.currency_id.rounding if rec.currency_id else 0.01
            rec.boq_matches_original = abs(difference) < rounding

    @api.depends('boq_line_ids.revised_amount')
    def _compute_revised_amount(self):
        for rec in self:
            rec.revised_amount = sum(rec.boq_line_ids.mapped('revised_amount')) if rec.boq_line_ids else rec.original_amount

    @api.depends('original_amount', 'advance_percent')
    def _compute_advance_amount(self):
        for rec in self:
            rec.advance_amount = (rec.original_amount or 0.0) * ((rec.advance_percent or 0.0) / 100.0)

    @api.depends('advance_amount', 'advance_recovered')
    def _compute_advance_balance(self):
        for rec in self:
            rec.advance_balance = (rec.advance_amount or 0.0) - (rec.advance_recovered or 0.0)

    def _compute_counts(self):
        for rec in self:
            rec.boq_line_count = len(rec.boq_line_ids)
            rec.contract_order_count = len(rec.contract_order_ids)
            rec.measurement_count = len(rec.measurement_ids)
            rec.ipc_count = len(rec.ipc_ids)

    def _compute_variation_count(self):
        for rec in self:
            rec.variation_count = self.env['construction.variation'].search_count([
                ('contract_id', '=', rec.id)
            ])

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', 'New') == 'New':
                vals['name'] = self.env['ir.sequence'].next_by_code('construction.contract') or 'New'
        return super().create(vals_list)

    @api.constrains('sale_order_id')
    def _check_unique_sale_order(self):
        for rec in self.filtered('sale_order_id'):
            duplicate = self.search_count([
                ('sale_order_id', '=', rec.sale_order_id.id),
                ('id', '!=', rec.id),
            ])
            if duplicate:
                raise ValidationError(_('A client contract already exists for Sales Order %s.') % rec.sale_order_id.name)

    def action_view_sale_order(self):
        self.ensure_one()
        if not self.sale_order_id:
            raise UserError(_('This contract is not linked to a Sales Order.'))
        return {
            'type': 'ir.actions.act_window',
            'name': _('Sales Order'),
            'res_model': 'sale.order',
            'view_mode': 'form',
            'res_id': self.sale_order_id.id,
            'target': 'current',
        }

    def action_refresh_from_sale_order(self):
        self.ensure_one()
        if not self.sale_order_id:
            raise UserError(_('This contract is not linked to a Sales Order.'))
        if self.contract_order_ids:
            raise UserError(_('Refresh the BOQ from the individual Contract Order instead. This contract contains separated Sales Order scopes.'))
        if self.state not in ('draft', 'under_review'):
            raise UserError(_('The BOQ can only be refreshed from Sales while the contract is Draft or Under Review.'))
        if self.measurement_ids or self.ipc_ids:
            raise UserError(_('You cannot rebuild the BOQ after measurements or IPCs have been created.'))
        approved_variations = self.env['construction.variation'].search_count([
            ('contract_id', '=', self.id),
            ('state', 'in', ['approved']),
        ])
        if approved_variations:
            raise UserError(_('You cannot rebuild the BOQ after an approved variation exists.'))

        order = self.sale_order_id
        self.boq_line_ids.unlink()
        vals = order._prepare_construction_contract_vals()
        vals.pop('sale_order_id', None)
        vals.pop('boq_line_ids', None)
        self.write({
            'partner_id': vals['partner_id'],
            'company_id': vals['company_id'],
            'currency_id': vals['currency_id'],
            'payment_term_id': vals['payment_term_id'],
            'customer_reference': vals['customer_reference'],
            'original_amount': vals['original_amount'],
            'scope': vals['scope'],
            'date_start': vals['date_start'],
        })
        if 'project_id' in vals:
            self.project_id = vals['project_id']
        self.write({'boq_line_ids': order._prepare_construction_boq_commands()})
        self.message_post(body=_('Contract header and BOQ refreshed from Sales Order %s.') % order.name)
        return {'type': 'ir.actions.client', 'tag': 'reload'}

    def _get_report_base_filename(self):
        self.ensure_one()
        return f"Contract_{self.name}"

    def action_submit_review(self):
        self.state = 'under_review'

    def action_approve(self):
        self.state = 'approved'

    def action_activate(self):
        self.state = 'active'

    def action_complete(self):
        self.state = 'completed'

    def action_close(self):
        self.state = 'closed'

    def action_cancel(self):
        self.state = 'cancelled'

    def action_reset_to_draft(self):
        self.state = 'draft'
    def action_view_contract_orders(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window', 'name': _('Contract Orders'),
            'res_model': 'construction.contract.order', 'view_mode': 'list,form',
            'domain': [('contract_id', '=', self.id)],
            'context': {'default_contract_id': self.id},
        }

    def action_view_measurements(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Measurements',
            'res_model': 'construction.measurement',
            'view_mode': 'list,form',
            'domain': [('contract_id', '=', self.id)],
            'context': {'default_contract_id': self.id},
        }

    def action_view_ipcs(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'IPCs',
            'res_model': 'construction.ipc',
            'view_mode': 'list,form',
            'domain': [('contract_id', '=', self.id)],
            'context': {'default_contract_id': self.id},
        }
    def action_view_variations(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Variations',
            'res_model': 'construction.variation',
            'view_mode': 'list,form',
            'domain': [('contract_id', '=', self.id)],
            'context': {'default_contract_id': self.id},
        }
    def _compute_advance_count(self):
        for rec in self:
            rec.advance_count = self.env['construction.advance'].search_count([
                ('contract_id', '=', rec.id)
            ])
    def action_view_advances(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Advances',
            'res_model': 'construction.advance',
            'view_mode': 'list,form',
            'domain': [('contract_id', '=', self.id)],
            'context': {'default_contract_id': self.id},
        }
    
    @api.depends(
        'ipc_ids.retention_amount',
        'ipc_ids.state',
        'retention_release_ids.amount',
        'retention_release_ids.state',
    )
    def _compute_retention_balances(self):
        for rec in self:
            held = sum(
                rec.ipc_ids.filtered(lambda x: x.state in ['approved', 'done']).mapped('retention_amount')
            )
            released = sum(
                rec.retention_release_ids.filtered(lambda x: x.state in ['posted']).mapped('amount')
            )
            rec.retention_held = held
            rec.retention_released = released
            rec.retention_balance = held - released


    def _compute_retention_release_count(self):
        for rec in self:
            rec.retention_release_count = self.env['construction.retention.release'].search_count([
                ('contract_id', '=', rec.id)
            ])


    def action_view_retention_releases(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Retention Releases',
            'res_model': 'construction.retention.release',
            'view_mode': 'list,form',
            'domain': [('contract_id', '=', self.id)],
            'context': {'default_contract_id': self.id},
        }
    
    @api.depends(
        'boq_line_ids.measured_qty',
        'boq_line_ids.certified_qty',
        'boq_line_ids.unit_rate',
        'boq_line_ids.revised_unit_rate',
        'ipc_ids.current_work_value',
        'ipc_ids.move_id',
        'ipc_ids.move_id.amount_total',
        'ipc_ids.move_id.payment_state',
        'ipc_ids.move_id.amount_residual',
        'revised_amount',
    )
    def _compute_summary_amounts(self):
        for rec in self:
            total_measured = 0.0
            total_certified = 0.0

            for line in rec.boq_line_ids.filtered(lambda l: not l.display_type):
                rate = line.revised_unit_rate or line.unit_rate
                total_measured += (line.measured_qty or 0.0) * rate
                total_certified += (line.certified_qty or 0.0) * rate

            moves = rec.ipc_ids.mapped('move_id').filtered(lambda m: m.state != 'cancel')
            total_move = sum(moves.mapped('amount_total'))
            total_paid = sum((m.amount_total - m.amount_residual) for m in moves)

            completion = 0.0
            if rec.revised_amount:
                completion = (total_certified / rec.revised_amount) * 100.0

            rec.total_measured_amount = total_measured
            rec.total_certified_amount = total_certified
            rec.total_move_amount = total_move
            rec.total_paid_amount = total_paid
            rec.completion_percent = completion
